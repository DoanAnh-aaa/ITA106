import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("learnx_user_behavior_dataset_10M.csv")
print(df.head())
print(df.shape)
print(df.info())

missing_values = df.isnull().sum()
print(missing_values)
df.fillna(df.median(numeric_only=True), inplace=True)

print(df.duplicated().sum())
df.drop_duplicates(inplace=True)

print("- Thống kê mô tả:")
print(df.describe())

plt.hist(df["avg_session_minutes"], bins=20)
plt.title("Phân phối thời gian học ")
plt.xlabel("Giờ")
plt.ylabel("Người dùng")
plt.show()

plt.boxplot(df["sessions_per_week"])
plt.title("Số lần truy cập mỗi tuần ")
plt.ylabel("Số lần")
plt.show()

plt.hist(df["completion_rate"], bins=10)
plt.title(" Mức độ hoàn thành")
plt.xlabel("Tỷ lệ hoàn thành")
plt.ylabel("Người dùng")
plt.show()

plt.boxplot(df["avg_session_minutes"])
plt.title("avg_session_minutes")
plt.show()

Q1 = df["avg_session_minutes"].quantile(0.25)
Q3 = df["avg_session_minutes"].quantile(0.75)
IQR = Q3 - Q1
lower = Q1 - 1.5 * IQR
upper = Q3 + 1.5 * IQR
outliers = df[(df["avg_session_minutes"] < lower) | (df["avg_session_minutes"] > upper)]
print("-Outliers:")
print(outliers)

heavy_users = df[df["avg_session_minutes"] > df["avg_session_minutes"].quantile(0.95)]
print("\n-Người dùng học cực nhiều:") 
print(heavy_users)

inactive = df[(df["courses_enrolled"] >= 3) & (df["avg_session_minutes"] <= 10)]
print("\n-Người dùng đăng kí nhiều khóa nhưng không học:")
print(inactive)

spenders = df[df["total_spent_usd"] > df["total_spent_usd"].quantile(0.95)]
print("\n-Người dùng chi tiêu bất thường:")
print(spenders)



