# Câu1: Người dùng LearnX sử dụng nền tảng ra sao?
-Người dùng có xu hướng sử dụng nhiều tính năng của nền tảng qua các video được xem và quiz hoàn thành.
-Qua các biểu đồ và thống kê mô tả, ta thấy đa số người dùng LearnX truy cập trung bình từ 3-7 phiên/tuần và thời lượng trung bình khoảng 20-60 phút/phiên; nhiều người đăng kí khóa học nhưng không học hoặc chỉ hoàn thành một phần khóa học dẫn đến tỉ lệ hoàn thành phân bố không đồng đều.

# Câu 2: Có outliers đáng chú ý nào không?
-Ta có thể nhận thấy outliers dựa trên IQR và Boxplot như outliers về thời gian học, về chi tiêu bất thường và tỉ lệ pass khóa học.
-Về thời gian học: Một số người dùng có số phiên học và thời lượng học/phiên rất cao.
-Về chi tiêu: Một số người dùng có sự chi tiêu bất thường, cao hơn so với mức trung bình.
-Về tỉ lệ hoàn thành khóa học: Đa số người dùng hoàn thành ở mức < 100% nhưng một số đạt ≈ 100%.

# Câu 3: Insight nào hữu ích cho đội sản phẩm?
-Insight 1: Tăng tính năng nhắc học, phần thưởng duy trì streak => Tỉ lệ pass cao hơn.
-Insight 2: Gợi ý các gói nâng cao cho người dùng đang xem nhiều video và miễn phí dùng thử gói 7 ngày hay 1 tháng => Khả năng tiếp cận và mua gói cao hơn đối với người xem nhiều video.
-Insight 3: Ứng dụng và cải thiện hệ thống AI => Người dùng có thể biết đến và đăng kí khóa học nhiêu hơn qua gợi ý hay các tính năng nổi bật của AI.
-Insight 4: Tạo lộ trình hoạc tập cá nhân hóa, gửi mail nhắc học bài => Giúp người học không cảm thấy mơ hồ, giảm tình trạng đăng kí khóa học nhưng ít hoặc không sử dụng.


